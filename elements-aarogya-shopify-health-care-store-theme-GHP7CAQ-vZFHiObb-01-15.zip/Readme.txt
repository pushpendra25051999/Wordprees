Within the main folder [Ayush-Pack-V1] there will be following folder and files.


Documentation
Readme.txt
Log.txt
Ayush.zip             



------------------------------------------------------------------------------------------------------------------------------------

http://themessupport.com/documentation/doc/ayush/

Kindly refer our documentation for installing the theme and doing customization. 
If you need any assistance, plz contact us through support@wedesignthemes.com


Thank You.
DesignThemes.










